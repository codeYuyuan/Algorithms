/**
 * Created by yuyuanliu on 2017-01-07.
 */
import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private WeightedQuickUnionUF grid;
    private int[][] openStatus;
    private int dimension;

    public Percolation(int n) {
        dimension = n;
        grid = new WeightedQuickUnionUF(n * n + 2);
        for (int i = 1; i <= n; i++) {
            grid.union(0, i);
        }
        for (int i = n * n; i > n * n - n; i--) {
            grid.union(n * n + 1, i);
        }
        openStatus = new int[n][n];
        for (int i = 0; i < dimension; i++)
            for (int j = 0; j < dimension; j++)
                openStatus[i][j] = 0;
    }           // create n-by-n grid, with all sites blocked

    public void open(int row, int col) {
        openStatus[row - 1][col - 1] = 1;
        int index = (row - 1) * dimension + col;
        if (row - 1 > 0)
            if (isOpen(row - 1, col))
                grid.union(index, index - dimension);
        if (row + 1 <= dimension)
            if (isOpen(row + 1, col))
                grid.union(index, index + dimension);
        if (col - 1 > 0)
            if (isOpen(row, col - 1))
                grid.union(index, index - 1);
        if (col + 1 <= dimension)
            if (isOpen(row, col + 1))
                grid.union(index, index + 1);
    }  // open site (row, col) if it is not open already

    public boolean isOpen(int row, int col) {
        if (openStatus[row - 1][col - 1] == 1) return true;
        return false;
    }  // is site (row, col) open?

    public boolean isFull(int row, int col) {
        return grid.connected(0, (row - 1) * dimension + col);
    }  // is site (row, col) full?

    public int numberOfOpenSites() {
        int count = 0;
        for (int i = 0; i < dimension; i++) {
            for (int j = 0; j < dimension; j++) {
                if (openStatus[i][j] == 1)
                    count++;
            }
        }
        return count;
    }       // number of open sites

    public boolean percolates() {
        return grid.connected(0, dimension * dimension + 1);
    }              // does the system percolate?
}

